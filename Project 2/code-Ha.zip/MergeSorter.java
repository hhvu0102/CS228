package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;
import java.util.ArrayList;

/**
 *  
 * @author HaVu
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{ 
		super(pts);
		algorithm = Algorithm.MergeSort.toString();
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
		mergeSortRec(points);
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
		int n = pts.length;
		if (n <= 1)
		{
			return;
		}
		else
		{
			int m = n/2;
			Point[] leftPts = new Point[m];
			Point[] rightPts = new Point[n-m];
			mergeSortRec(leftPts);
			mergeSortRec(rightPts);
			pts = mergePoints(leftPts, rightPts);
		}
	}
	
	/**
	 * Helper method to merge two point arrays
	 * @param arr1  point array 1
	 * @param arr2  point array 2
	 * @return a merged array of arr1 and arr2
	 */
	private Point[] mergePoints(Point[] arr1, Point[] arr2)
	{
		int p = arr1.length;
		int q = arr2.length;
		ArrayList<Point> result = new ArrayList<>();
		int i = 0;
		int j = 0;
		while (i < p && j < q)
		{
			if (arr1[i].compareTo(arr2[j]) <= 0)
			{
				result.add(arr1[i]);
				i++;
			}
			else
			{
				result.add(arr2[j]);
				j++;
			}
		}
		if (i >= p)
		{
			while (j < q)
			{
				result.add(arr2[j]);
				j++;
			}
		}
		else
		{
			while (i < p)
			{
				result.add(arr1[i]);
				i++;
			}
		}
		
		Point[] result2 = new Point[result.size()];
		for (int k = 0; k < result.size(); k++)
		{
			result2[k] = result.get(k);
		}
		
		return result2;
	}
}
